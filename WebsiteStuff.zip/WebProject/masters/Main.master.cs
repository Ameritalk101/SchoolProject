﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class masters_Main : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Set the current page's menu item to "selected"

        if (Page.AppRelativeVirtualPath.Contains("/Stuff/Development"))
        {
            mainMenuStuff.Attributes.Add("class", "selected");
            sideMenuDev.Attributes.Add("class", "selected");
        }
        else if (Page.AppRelativeVirtualPath.Contains("/Stuff/Design"))
        {
            mainMenuStuff.Attributes.Add("class", "selected");
            sideMenuDes.Attributes.Add("class", "selected");
        }
        else if (Page.AppRelativeVirtualPath.Contains("/Stuff"))
        {
            mainMenuStuff.Attributes.Add("class", "selected");
            sideMenuStuff.Attributes.Add("class", "selected");
        }
        else if (Page.AppRelativeVirtualPath.Contains("/Members"))
        {
            mainMenuMembers.Attributes.Add("class", "selected");
            sideMenuMembers.Attributes.Add("class", "selected");
        }
        else if (Page.AppRelativeVirtualPath.Contains("/About"))
        {
            mainMenuAbout.Attributes.Add("class", "selected");
            sideMenuAbout.Attributes.Add("class", "selected");
        }
        else if (Page.AppRelativeVirtualPath.Contains("/Contact"))
        {
            mainMenuContact.Attributes.Add("class", "selected");
            sideMenuContact.Attributes.Add("class", "selected");
        }
        else
        {
            mainMenuHome.Attributes.Add("class", "selected");
            sideMenuHome.Attributes.Add("class", "selected");
        }

        // Display login form or welcome message
        if (HttpContext.Current.User.Identity.IsAuthenticated)
        {
            LoginLogin.Attributes.Add("class", "hide");
            LoginWelcome.Attributes.Add("class", "bg");
        }
        else
        {
            LoginLogin.Attributes.Add("class", "bg");
            LoginWelcome.Attributes.Add("class", "hide");
        }
    }
}

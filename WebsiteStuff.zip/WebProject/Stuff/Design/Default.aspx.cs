﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Stuff_Design_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lvDataSource.DataSourceID = "SqlDataSourceCategory";
            SqlDataSourceCategory.SelectParameters.Add("Category", "Des");
        }
    }

    protected void ddlSubCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        String selection = ddlSubCategory.SelectedValue;

        SqlDataSourceCategory.SelectParameters.Clear();
        SqlDataSourceSubCategory.SelectParameters.Clear();

        if (selection == "All")
        {
            lvDataSource.DataSourceID = "SqlDataSourceCategory";
            SqlDataSourceCategory.SelectParameters.Add("Category", "Des");
        }
        else
        {
            lvDataSource.DataSourceID = "SqlDataSourceSubCategory";
            SqlDataSourceSubCategory.SelectParameters.Add("SubCategory", selection);
        }
    }
}
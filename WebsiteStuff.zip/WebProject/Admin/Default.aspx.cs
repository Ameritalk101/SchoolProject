﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    // Add a link to the database
    protected void btnAddLink_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            String sponsorChecked;
            if (chkLinkSponsor.Checked)
                sponsorChecked = "1";
            else
                sponsorChecked = "0";

            var parameters = SqlDataSource1.InsertParameters;
            parameters["Title"].DefaultValue = txtLinkTitle.Text;
            parameters["Description"].DefaultValue = txtLinkDescription.Text;
            parameters["URL"].DefaultValue = txtLinkURL.Text;
            parameters["Category"].DefaultValue = txtLinkCategory.Text;
            parameters["SubCategory"].DefaultValue = txtLinkSubCategory.Text;
            parameters["Sponsor"].DefaultValue = sponsorChecked;

            try
            {
                SqlDataSource1.Insert();
                txtLinkTitle.Text = "";
                txtLinkDescription.Text = "";
                txtLinkURL.Text = "";
                txtLinkCategory.Text = "";
                txtLinkSubCategory.Text = "";
                chkLinkSponsor.Checked = false;
                ScriptManager.RegisterClientScriptBlock(this, GetType(),
                    "alertMessage", "alert('Link Added Successfully')", true);
            }
            catch (Exception ex)
            {
                lblAddLinkError.Text = "A database error has occurred." +
                    " Message: " + ex.Message;
            }
        }
    }
}